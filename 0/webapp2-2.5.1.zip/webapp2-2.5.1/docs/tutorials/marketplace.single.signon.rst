.. _tutorials.marketplace.single.signon:

(work in progress)

Single sign on with webapp2 and the Google Apps Marketplace
===========================================================
